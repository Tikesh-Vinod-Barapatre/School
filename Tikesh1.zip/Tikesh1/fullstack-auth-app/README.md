# Music Recommendation Website

A fullstack MERN app with authentication. See folder structure for details.